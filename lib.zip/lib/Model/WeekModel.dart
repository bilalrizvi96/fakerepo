class WeekModel {
  var range;
  var selected;
  var weekdata;
  WeekModel({this.range, this.selected, this.weekdata});
}
