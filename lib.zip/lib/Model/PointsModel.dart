class PointsModel {
  var Title;
  var decription, point, color, textcolor;

  PointsModel(
      {this.Title, this.decription, this.point, this.color, this.textcolor});
}
