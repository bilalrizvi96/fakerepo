class MaintenanceModel {
  var message;
  MaintenanceModel({this.message});
}
